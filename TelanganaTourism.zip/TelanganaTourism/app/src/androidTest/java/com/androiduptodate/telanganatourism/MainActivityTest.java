package com.androiduptodate.telanganatourism;

import org.junit.Test;

import static org.junit.Assert.*;

public class MainActivityTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void onNavigationItemSelected() {
    }

    @Test
    public void onBackPressed() {
    }
}