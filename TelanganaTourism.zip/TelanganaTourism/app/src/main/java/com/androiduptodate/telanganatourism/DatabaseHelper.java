package com.androiduptodate.telanganatourism;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME="register.db";
    public static final String TABLENAME="register";
    public static final String COL_1="ID";
    public static final String COL_2="FirstName";
    public static final String COL_3="LastName";
    public static final String COL_4="Email";
    public static final String COL_5="Password";
    public static final String COL_6="Phone";
    public DatabaseHelper(Context context) {
        super(context,DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE "+TABLENAME+" (ID INTEGER PRIMARY KEY AUTOINCREMENT,FirstName TEXT not null,LastName TEXT not null,Email TEXT not null unique,Password TEXT not null,Phone TEXT not null)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLENAME);
        onCreate(db);
    }

    public boolean insertData(String trim, String trim1, String trim2, String trim3, String trim4) {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put(COL_2,trim);
        contentValues.put(COL_3,trim1);
        contentValues.put(COL_4,trim2);
        contentValues.put(COL_5,trim3);
        contentValues.put(COL_6,trim4);

        long result=db.insert(TABLENAME,null,contentValues);
        if(result==-1)
            return false;
        else
            return true;
    }

    public Cursor checkData(String user, String pass) {
        String[] columns={ COL_2,COL_4};
        String selection = COL_4+ "=?"+" and "+COL_5 + "=?";
        String []selectionArgs={user,pass};
        SQLiteDatabase database=this.getReadableDatabase();
        Cursor res=database.query(TABLENAME,columns,selection,selectionArgs,null,null,null);
        int count=res.getCount();
        database.close();
        return res;
    }

}

