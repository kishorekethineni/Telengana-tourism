package com.androiduptodate.telanganatourism;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

class boatingadapter extends RecyclerView.Adapter<boatingadapter.ProductViewHolder> {


    //this context we will use to inflate the layout
    private Context mCtx;

    //we are storing all the products in a list
    private List<boatingg> boatlist;

    //getting the context and product list with constructor
    public boatingadapter(Context mCtx, List<boatingg> boatlist) {
        this.mCtx = mCtx;
        this.boatlist = boatlist;
    }

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflating and returning our view holder
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.boatingitems, null);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ProductViewHolder holder, int position) {
        //getting the product of the specified position
       boatingg boat = boatlist.get(position);

        //binding the data with the viewholder views
        holder.textViewTitle.setText(boat.getTitle());
        holder.textViewRating.setText(String.valueOf(boat.getRating()));
        holder.textViewPrice.setText(String.valueOf(boat.getPrice()));

        holder.imageView.setImageDrawable(mCtx.getResources().getDrawable(boat.getImage()));

    }


    @Override
    public int getItemCount() {
        return boatlist.size();
    }


    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView textViewTitle, textViewRating, textViewPrice;
        ImageView imageView;

        public ProductViewHolder(View itemView) {
            super(itemView);

            textViewTitle = itemView.findViewById(R.id.textViewTitle11);
            textViewRating = itemView.findViewById(R.id.textViewRating11);
            textViewPrice = itemView.findViewById(R.id.textViewPrice11);
            imageView = itemView.findViewById(R.id.imageView11);
        }
    }
}

