package com.androiduptodate.telanganatourism;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


public class placehistoric extends Fragment {

    View v;
    List<historicc> historiccList;
    RecyclerView recyclerViewh;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment_placehistoric, container, false);

        recyclerViewh = (RecyclerView)v.findViewById(R.id.historicrvv);
        recyclerViewh.setHasFixedSize(true);
        recyclerViewh.setLayoutManager(new LinearLayoutManager(getActivity()));

        //initializing the productlist
        historiccList = new ArrayList<>();

        historiccList.add(
                new historicc(
                        1,
                        "Golconda Fort",
                        "Historic",
                        "Ibrahim Bhag",
                        "Hyderabad",
                        R.drawable.golconda));

        historiccList.add(
                new historicc(
                        2,
                        "Charminar",
                        "Historic",
                        "Old Basthi",
                        "Secunderabad",
                        R.drawable.charminar));


        historiccList.add(
                new historicc(
                        3,
                        "Birla Mandir",
                        "Historic",
                        "Khairatabad",
                        "Hyderabad",
                        R.drawable.birlamandir));

        historiccList.add(
                new historicc(
                        4,
                        "Qutub Sahi Tombs",
                        "Historic",
                        "Banjara Darwaza",
                        "Nirmal",
                        R.drawable.qutub));

        //creating recyclerview adapter
        historicadapter adapter2 = new historicadapter(getActivity(), historiccList);

        //setting adapter to recyclerview
        recyclerViewh.setAdapter(adapter2);



        recyclerViewh.addOnItemTouchListener(new historicrecyclerviewlistener(getActivity(), recyclerViewh, new historicrecyclerviewlistener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                switch (position) {
                    case 0:
                        getFragmentManager().beginTransaction().replace(R.id.fragment_container, new golcondafort()).commit();
                        break;
                    case 1:
                        getFragmentManager().beginTransaction().replace(R.id.fragment_container, new charminar()).commit();
                        break;
                    case 2:
                        getFragmentManager().beginTransaction().replace(R.id.fragment_container, new birlamandir()).commit();
                        break;
                    case 3:
                        getFragmentManager().beginTransaction().replace(R.id.fragment_container, new qubsahitombs()).commit();
                        break;
                }
            }

            @Override
            public void onLongItemClick(View view, int position) {

            }
        }));



        return v;
    }

    }
