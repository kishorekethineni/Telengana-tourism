package com.androiduptodate.telanganatourism;


import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;

import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class eventform extends AppCompatActivity {
    private TextInputLayout textInputEmail,textInputpassword;
    String fname,username;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eventform);
        textInputEmail=findViewById(R.id.text_input_email);
        textInputpassword=findViewById(R.id.text_input_password);
        db=new DatabaseHelper(this);

    }
    public void doLogin(View view) {
        String user = textInputEmail.getEditText().getText().toString().trim();
        String pass = textInputpassword.getEditText().getText().toString().trim();
        if (!validateEmail() | !validatePassword()) {
            Toast.makeText(this, "Check your credentials", Toast.LENGTH_SHORT).show();
            ;
        } else {
            Cursor res = db.checkData(user, pass);
            int count = res.getCount();
            if (count == 1) {
                Intent intent = new Intent(eventform.this, eventinfo.class);
                res.moveToFirst();
                fname = res.getString(0);
                username = res.getString(1);
                /*while (res.moveToNext()){
                    fname=res.getString(1);
                    username=res.getString(3);
                }*/
                intent.putExtra("fname", fname);
                intent.putExtra("username", username);
                startActivity(intent);
                Toast.makeText(this, "Success fully logined " + res, Toast.LENGTH_SHORT).show();
            } else
                Toast.makeText(this, "wrong credentials", Toast.LENGTH_SHORT).show();
        }

    }




        public void doRegister(View view) {
        startActivity(new Intent(eventform.this,registeractivity.class));
    }
    private boolean validateEmail()
    {
        String emailInput=textInputEmail.getEditText().getText().toString().trim();
        if(emailInput.isEmpty()){
            textInputEmail.setError("Field cannot be empty");
            return false;}
        else{
            textInputEmail.setError(null);
            return true;
        }
    }

    private boolean validatePassword()
    {
        String passwordInput=textInputpassword.getEditText().getText().toString().trim();
        if(passwordInput.isEmpty()){
            textInputpassword.setError("Field cannot be empty");
            return false;}
        else{
            textInputpassword.setError(null);
            return true;
        }
    }

}
