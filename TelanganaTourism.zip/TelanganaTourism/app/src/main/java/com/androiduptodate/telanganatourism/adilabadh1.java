package com.androiduptodate.telanganatourism;


import android.Manifest;
import android.app.Fragment;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;


/**
 * A simple {@link Fragment} subclass.
 */
public class adilabadh1 extends android.support.v4.app.Fragment implements View.OnClickListener {
Button c1,c2,c3,c4;
View v;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v= inflater.inflate(R.layout.fragment_adilabadh1, container, false);

        c1=(Button)v.findViewById(R.id.call1);
        c2=(Button)v.findViewById(R.id.call2);
        c3=(Button)v.findViewById(R.id.call3);
        c4=(Button)v.findViewById(R.id.call4);
        c1.setOnClickListener(this);
        c2.setOnClickListener(this);
        c3.setOnClickListener(this);
        c4.setOnClickListener(this);

        return v;
    }

    @Override

    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.call1:
                Intent i=new Intent(Intent.ACTION_DIAL);
                i.setData(Uri.parse("tel:9505123217"));
                startActivity(i);
            case R.id.call2:
                Intent i1=new Intent(Intent.ACTION_DIAL);
                i1.setData(Uri.parse("tel:9505123217"));
                startActivity(i1);
            case R.id.call3:
                Intent i2=new Intent(Intent.ACTION_DIAL);
                i2.setData(Uri.parse("tel:9505123217"));
                startActivity(i2);
            case R.id.call4:
                Intent i3=new Intent(Intent.ACTION_DIAL);
                i3.setData(Uri.parse("tel:9505123217"));
                startActivity(i3);

        }

    }
}
