package com.androiduptodate.telanganatourism;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class soundandlight extends Fragment  {
    View v;
    List<eventto> eventlist;
    RecyclerView recyclerViewev;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v=inflater.inflate(R.layout.soundandlight,container,false);

        recyclerViewev = (RecyclerView)v.findViewById(R.id.eventrecycler);
        recyclerViewev.setHasFixedSize(true);
        recyclerViewev.setLayoutManager(new LinearLayoutManager(getActivity()));

        //initializing the productlist
       eventlist = new ArrayList<>();
        eventlist.add(new eventto("sanskrithi",R.drawable.eventsanskruthi));
        eventlist.add(new eventto("Nipuna",R.drawable.eventnipuna));
        eventlist.add(new eventto("Rigolade",R.drawable.eventrigolade));
        eventlist.add(new eventto("Roboveda",R.drawable.eventroboveda));
        eventlist.add(new eventto("Stockon",R.drawable.eventstockonoimcs));
        eventlist.add(new eventto("Sigmond",R.drawable.eventsigmond));

        eventadapter adapter = new eventadapter(getActivity(),eventlist);

        //setting adapter to recyclerview
        recyclerViewev.setAdapter(adapter);
        recyclerViewev.addOnItemTouchListener(new eventrecyclerviewlistener(getActivity(), recyclerViewev, new eventrecyclerviewlistener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                switch (position) {
                    case 0:
                        Intent i=new Intent(getActivity(),eventform.class);
                        startActivity(i);
                        break;
                    case 1:
                        Intent i1=new Intent(getActivity(),eventform.class);
                        startActivity(i1);
                        break;
                    case 2:
                        Intent i2=new Intent(getActivity(),eventform.class);
                        startActivity(i2);
                        break;
                    case 3:
                        Intent i3=new Intent(getActivity(),eventform.class);
                        startActivity(i3);
                        break;
                    case 4:
                        Intent i4=new Intent(getActivity(),eventform.class);
                        startActivity(i4);
                        break;
                    case 5:
                        Intent i5=new Intent(getActivity(),eventform.class);
                        startActivity(i5);
                        break;

                }
            }

            @Override
            public void onLongItemClick(View view, int position) {

            }
        }));




        return v;
    }


}

