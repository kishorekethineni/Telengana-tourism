package com.androiduptodate.telanganatourism;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

class religiousadapter extends RecyclerView.Adapter<religiousadapter.ProductViewHolder> {


    //this context we will use to inflate the layout
    private Context mCtx;

    //we are storing all the products in a list
    private List<religicc> relegiouslist;

    //getting the context and product list with constructor
    public religiousadapter(Context mCtx, List<religicc> religiouslist) {
        this.mCtx = mCtx;
        this.relegiouslist = religiouslist;
    }

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflating and returning our view holder
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.religiousitem, null);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ProductViewHolder holder, int position) {
        //getting the product of the specified position
        religicc religicc = relegiouslist.get(position);

        //binding the data with the viewholder views
        holder.textViewTitle.setText(religicc.getTitle());
        holder.textViewShortDesc.setText(religicc.getShortdesc());
        holder.textViewRating.setText(String.valueOf(religicc.getRating()));
        holder.textViewPrice.setText(String.valueOf(religicc.getPrice()));

        holder.imageView.setImageDrawable(mCtx.getResources().getDrawable(religicc.getImage()));

    }


    @Override
    public int getItemCount() {
        return relegiouslist.size();
    }


    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView textViewTitle, textViewShortDesc, textViewRating, textViewPrice;
        ImageView imageView;

        public ProductViewHolder(View itemView) {
            super(itemView);

            textViewTitle = itemView.findViewById(R.id.textViewTitleb2);
            textViewShortDesc = itemView.findViewById(R.id.textViewShortDescb3);
            textViewRating = itemView.findViewById(R.id.textViewRatingb4);
            textViewPrice = itemView.findViewById(R.id.textViewPriceb5);
            imageView = itemView.findViewById(R.id.imageViewb1);
        }
    }
}