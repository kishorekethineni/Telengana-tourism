package com.androiduptodate.telanganatourism;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;


public class placereligious extends Fragment {

    View v;
    List<religicc> relegiouslist;
    RecyclerView recyclerViewr;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment_placereligious, container, false);

        recyclerViewr = (RecyclerView)v.findViewById(R.id.religiousrv);
        recyclerViewr.setHasFixedSize(true);
        recyclerViewr.setLayoutManager(new LinearLayoutManager(getActivity()));

        //initializing the productlist
        relegiouslist = new ArrayList<>();

        relegiouslist.add(
                new religicc(
                        1,
                        "Yadhagirigutta",
                        "It is Located at the hill top",
                        "Bhongiri",
                        "Yadhadhri",
                        R.drawable.yadagirigutta));

        relegiouslist.add(
                new religicc(
                        2,
                        "Bhadrakali Temple",
                        "Religiuos Pilgrim",
                        "Warangal",
                        "Warangal",
                        R.drawable.badhrakalitemple));


        relegiouslist.add(
                new religicc(
                        3,
                        "Jagannath Temple",
                        "Religious Pilgrim",
                        "Banjara Hills",
                        "Hyderabad",
                        R.drawable.jagannathtemple));

        relegiouslist.add(
                new religicc(
                        4,
                        "Saraswati Temple",
                        "Religious Pilgrim",
                        "Basara",
                        "Nizambad",
                        R.drawable.saraswatitemple));

        //creating recyclerview adapter
       religiousadapter adapter3 = new religiousadapter(getActivity(), relegiouslist);

        //setting adapter to recyclerview
        recyclerViewr.setAdapter(adapter3);


        recyclerViewr.addOnItemTouchListener(new religiousrecyclerviewlistener(getActivity(), recyclerViewr, new religiousrecyclerviewlistener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                switch (position) {
                    case 0:
                        getFragmentManager().beginTransaction().replace(R.id.fragment_container, new yadhagirigutta()).commit();
                        break;
                    case 1:
                        getFragmentManager().beginTransaction().replace(R.id.fragment_container, new badhrakalitemple()).commit();
                        break;
                    case 2:
                        getFragmentManager().beginTransaction().replace(R.id.fragment_container, new jaganathtemple()).commit();
                        break;
                    case 3:
                        getFragmentManager().beginTransaction().replace(R.id.fragment_container, new saraswathitemple()).commit();
                        break;
                }
            }

            @Override
            public void onLongItemClick(View view, int position) {

            }
        }));


        return v;
    }

}

