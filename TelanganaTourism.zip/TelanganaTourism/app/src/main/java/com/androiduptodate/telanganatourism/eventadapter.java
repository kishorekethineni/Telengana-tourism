








































































package com.androiduptodate.telanganatourism;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

class eventadapter extends RecyclerView.Adapter<eventadapter.ProductViewHolder> {


    //this context we will use to inflate the layout
    private Context mCtx;

    //we are storing all the products in a list
    private List<eventto> eventlist;

    //getting the context and product list with constructor
    public eventadapter(Context mCtx, List<eventto> eventlist) {
        this.mCtx = mCtx;
        this.eventlist = eventlist;
    }

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflating and returning our view holder
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.eventitem, null);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ProductViewHolder holder, int position) {
        //getting the product of the specified position
        eventto event = eventlist.get(position);

        //binding the data with the viewholder views
        holder.textViewTitle.setText(event.getTitle());


        holder.imageView.setImageDrawable(mCtx.getResources().getDrawable(event.getImage()));

    }


    @Override
    public int getItemCount() {
        return eventlist.size();
    }


    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView textViewTitle;
        ImageView imageView;

        public ProductViewHolder(View itemView) {
            super(itemView);

            textViewTitle = itemView.findViewById(R.id.eventtv);

            imageView = itemView.findViewById(R.id.eventiv);
        }
    }
}
