package com.androiduptodate.telanganatourism;

import android.content.Intent;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Toast;

import java.util.regex.Pattern;

public class registeractivity extends AppCompatActivity {

        DatabaseHelper db;
        public static final Pattern PASSWORD_PATTERN=Pattern.compile("^" +
                "(?=.*[0-9])"+
                "(?=.*[a-z])"+
                "(?=.*[A-Z])"+
                "(?=.*[@#$%^&+=])"+
                "(?=\\\\S+$)"+
                ".{4,}"+
                "$");
        private TextInputLayout textInputrfirst_name,textInputrpassword,textInputrrpassword,textInputrlast_name,textInputrEmail,textInputrphone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registeractivity);

        textInputrfirst_name=findViewById(R.id.text_input_rfirst_name);
        textInputrpassword=findViewById(R.id.text_input_rpassword);
        textInputrrpassword=findViewById(R.id.text_input_rrpassword);
        textInputrlast_name=findViewById(R.id.text_input_rlast_name);
        textInputrEmail=findViewById(R.id.text_input_remail);
        textInputrphone=findViewById(R.id.text_input_rphone);
        db=new DatabaseHelper(this);
    }

    private boolean validaterFirstname()
    {
        String emailInput=textInputrfirst_name.getEditText().getText().toString().trim();
        if(emailInput.isEmpty()){
            textInputrfirst_name.setError("Field cannot be empty");
            return false;}
        else{
            textInputrfirst_name.setError(null);
            return true;
        }
    }
    private boolean validaterLastname()
    {
        String emailInput=textInputrlast_name.getEditText().getText().toString().trim();
        if(emailInput.isEmpty()){
            textInputrlast_name.setError("Field cannot be empty");
            return false;}
        else{
            textInputrlast_name.setError(null);
            return true;
        }
    }
    private boolean validaterphone()
    {
        String emailInput=textInputrphone.getEditText().getText().toString().trim();
        if(emailInput.isEmpty()){
            textInputrphone.setError("Field cannot be empty");
            return false;}
        // else if(!Patterns.PHONE.matcher(emailInput).matches()){
        //textInputrphone.setError("please enter vaild phone number");
        //return false;
        // }
        else{
            textInputrphone.setError(null);
            return true;
        }
    }

    private boolean validateEmail()
    {
        String emailInput=textInputrEmail.getEditText().getText().toString().trim();
        if(emailInput.isEmpty()){
            textInputrEmail.setError("Field cannot be empty");
            return false;
        }
        else if(!Patterns.EMAIL_ADDRESS.matcher(emailInput).matches())
        {
            textInputrEmail.setError("Please Enter valid email address");
            return false;
        }
        else{
            textInputrEmail.setError(null);
            return true;
        }
    }
    private boolean validaterpass()
    {
        String pass1=textInputrpassword.getEditText().getText().toString().trim();
        String pass2=textInputrrpassword.getEditText().getText().toString().trim();
        if(pass1.isEmpty()&& pass2.isEmpty()){
            textInputrpassword.setError("Field cannot be empty");
            return false;}
        else if(!pass1.equals(pass2)){
            textInputrpassword.setError("passwords are not matched ");
            return false;
        }
        else{
            textInputrpassword.setError(null);
            return true;
        }
    }

    public void dorRegister(View view) {
        if(!validaterFirstname()||!validaterLastname()||!validateEmail()||!validaterpass()||!validaterphone())
        {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean isinserted=db.insertData(textInputrfirst_name.getEditText().getText().toString().trim(),textInputrlast_name.getEditText().getText().toString().trim(),textInputrEmail.getEditText().getText().toString().trim(),textInputrpassword.getEditText().getText().toString().trim(),textInputrphone.getEditText().getText().toString().trim());
        Toast.makeText(this,"Registered Successfully", Toast.LENGTH_SHORT).show();
        if(isinserted){
            Toast.makeText(this, "Inserted Succsses fully", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(registeractivity.this,eventform.class));}
        else
            Toast.makeText(this, "Not inserted", Toast.LENGTH_SHORT).show();
    }
}
