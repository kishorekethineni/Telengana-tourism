package com.androiduptodate.telanganatourism;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

class historicadapter extends RecyclerView.Adapter<historicadapter.ProductViewHolder> {


    //this context we will use to inflate the layout
    private Context mCtx;

    //we are storing all the products in a list
    private List<historicc> historiccList;

    //getting the context and product list with constructor
    public historicadapter(Context mCtx, List<historicc> historiccList) {
        this.mCtx = mCtx;
        this.historiccList = historiccList;
    }

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //inflating and returning our view holder
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.historicitems, null);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ProductViewHolder holder, int position) {
        //getting the product of the specified position
       historicc history = historiccList.get(position);

        //binding the data with the viewholder views
        holder.textViewTitle.setText(history.getTitle());
        holder.textViewShortDesc.setText(history.getShortdesc());
        holder.textViewRating.setText(String.valueOf(history.getRating()));
        holder.textViewPrice.setText(String.valueOf(history.getPrice()));

        holder.imageView.setImageDrawable(mCtx.getResources().getDrawable(history.getImage()));

    }


    @Override
    public int getItemCount() {
        return historiccList.size();
    }


    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView textViewTitle, textViewShortDesc, textViewRating, textViewPrice;
        ImageView imageView;

        public ProductViewHolder(View itemView) {
            super(itemView);

            textViewTitle = itemView.findViewById(R.id.textViewTitlea2);
            textViewShortDesc = itemView.findViewById(R.id.textViewShortDesca3);
            textViewRating = itemView.findViewById(R.id.textViewRatinga4);
            textViewPrice = itemView.findViewById(R.id.textViewPricea5);
            imageView = itemView.findViewById(R.id.imageViewa1);
        }
    }
}
