package com.androiduptodate.telanganatourism;

import org.junit.Test;

import static org.junit.Assert.*;

public class eventformTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void doLogin() {

    }

    @Test
    public void doRegister() {
    }
}